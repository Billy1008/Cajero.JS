// VARIABLES PRINCIPALES
var usuario= null;                // Almacena el datos del usuario registrado
let intentosLogin = 0;             // Contador de intentos fallidos de login
let sesionActiva = false;          // Bandera que indica si hay una sesión activa
let ultimoMovimiento = null;       // Objeto para guardar el último movimiento

// FUNCIÓN PRINCIPAL - PUNTO DE ENTRADA DEL SISTEMA

function iniciarSistema() {
    console.clear();  // Limpiar la consola
    
    // Mostrar menú principal
    console.log("=== CAJERO AUTOMÁTICO DE BANCOLOMBIA:  ===");
    console.log("-Donde se cae el sistema todos los fines de mes 👌🟢");
    console.log("1. Registrar nueva cuenta");
    console.log("2. Iniciar sesión");
    console.log("3. Salir");
    
    // Solicitar opción al usuario
    const opcion = prompt("Seleccione una opción (1-3): \n1. Registrar nueva cuenta \n2. Iniciar sesión \n3.Salir ");
    
    // Manejar la opción seleccionada
    switch(opcion) {
        case "1":
            registrarUsuario();  // Llamar función de registro
            break;
        case "2":
            iniciarSesion();     // Llamar función de login
            break;
        case "3":
            alert("¡Gracias por usar nuestro cajero!");
            break;
        default:
            console.log("Opción no válida");
            setTimeout(iniciarSistema, 1000);//funcion( donde quieres que te redirija,tiempo de espera)
    }
}



// FUNCIÓN PARA REGISTRAR NUEVO USUARIO
function registrarUsuario() {
    console.clear();// Limpiar la consola
    console.log("=== REGISTRAR NUEVA CUENTA ===");
    
    // Verificar si ya hay un usuario registrado
    if (usuario !== null) {
        console.log("❌ Ya existe una cuenta registrada.");
        setTimeout(iniciarSistema, 2000);//funcion( donde quieres que te redirija,tiempo de espera)
        return;
    }
    
    // Capturar datos del usuario con prompts
    const identificacion = prompt("Ingrese su número de identificación:");
    const nombreUsuario = prompt("Cree un nombre de usuario:");
    const correo = prompt("Ingrese su correo electrónico:");
    const clave = prompt("Cree una contraseña:");
    const confirmarClave = prompt("Confirme su contraseña:");
    
    // Validar que las contraseñas coincidan !== estrictamente diferente
    if (clave !== confirmarClave) {
        console.log("❌ Las contraseñas no coinciden. Intente nuevamente.");
        setTimeout(registrarUsuario, 2000);//funcion( donde quieres que te redirija,tiempo de espera)
        return;
    }
    
    // Validar que todos los campos estén completos
    if (!identificacion || !nombreUsuario || !correo || !clave) {
        console.log("❌ Todos los campos son obligatorios.");
        setTimeout(registrarUsuario, 2000);
        return;
    }
    
    // Crear el objeto usuario con los datos capturados, OBJETO lo guardamos en la variable global 'usuario'
    usuario = {
        //porpiedad  : datos del prompt
        identificacion: identificacion, 
        nombreUsuario: nombreUsuario,
        correo: correo,
        clave: clave,
        saldo: 0,                   // Saldo inicial en 0
        bloqueada: false
    };
    
    // se crea un objeto y lo guardamos en la varible ultimoMovimiento :OBJETOS guardados en VARIABLES GLOBALES
    ultimoMovimiento = {
        tipo: "Apertura de cuenta",
        monto: 0,
      //fecha:Fx de fecha/hora().Convierte a formato de tu país
        fecha: new Date().toLocaleString()
    };
    
    console.log("✅ ¡Cuenta creada exitosamente!");
    console.log(`Bienvenido/a ${nombreUsuario}`);
    console.log("Su saldo inicial es: $0");
    
    setTimeout(iniciarSistema, 3000);//funcion( donde quieres que te redirija,tiempo de espera)
}




// FUNCIÓN DE INICIO DE SESIÓN CON VALIDACIÓN

function iniciarSesion() {
    console.clear();
    console.log("=== INICIAR SESIÓN ===");
    
    // Verificar si no hay usuarios registrados
    if (usuario === null) {
        console.log("❌ No hay cuentas registradas. Por favor regístrese primero.");
        setTimeout(iniciarSistema, 2000);
        return;
    }
    
    // Verificar si la cuenta está bloqueada
    if (usuario.bloqueada) {
        console.log("❌ Cuenta bloqueada. Contacte al banco.");
        setTimeout(iniciarSistema, 2000);
        return;
    }
    
    // Solicitar credenciales al usuario
    const inputUsuario = prompt("Ingrese su usuario:");
    const inputClave = prompt("Ingrese su contraseña:");
    
    // Validar credenciales, se valida las propiedades del objeto que sean iguales al prompt === estrictamente = && logico
    if (inputUsuario === usuario.nombreUsuario && inputClave === usuario.clave) {
        console.log("✅ ¡Login exitoso!");
        intentosLogin = 0;        // Reiniciar contador de intentos
        sesionActiva = true;      // Activar bandera de sesión
        setTimeout(mostrarMenuPrincipal, 1000);
    } else {
        intentosLogin++;          // Incrementar intentos fallidos
        
        console.log(`❌ Credenciales incorrectas. Intento ${intentosLogin}/3`);
        
        // Bloquear cuenta después de 3 intentos fallidos
        if (intentosLogin >= 3) {
            usuario.bloqueada = true;
            console.log("🚫 Cuenta bloqueada por seguridad");
        }
        
        setTimeout(iniciarSistema, 2000);
    }
}



// MENÚ PRINCIPAL DESPUÉS DEL LOGIN
function mostrarMenuPrincipal() {
    console.clear();
    console.log("=== MENÚ PRINCIPAL ===");
    console.log(`Usuario: ${usuario.nombreUsuario}`);//accedemos la objeto con la propiedad
    console.log("1. Consultar saldo");
    console.log("2. Retirar dinero");
    console.log("3. Consignar dinero");
    console.log("4. Ver último movimiento");
    console.log("5. Cambiar contraseña");
    console.log("6. Cerrar sesión");

    //opcion del prompt
    const opcion = prompt("Seleccione una opción (1-6): \n1. Consultar saldo \n2. Retirar dinero \n3. Consignar dinero  \n4. Ver último movimiento \n5. Cambiar contraseña \n6. Cerrar sesión");
    
    // Navegación del menú principal
    switch(opcion) {
        case "1":
            consultarSaldo();
            break;
        case "2":
            retirarDinero();
            break;
        case "3":
            consignarDinero();
            break;
        case "4":
            verUltimoMovimiento();
            break;
        case "5":
            cambiarContrasena();
            break;
        case "6":
            cerrarSesion();
            break;
        default:
            console.log("Opción no válida");
            setTimeout(mostrarMenuPrincipal, 1000);
    }
}



// CONSULTAR SALDO ACTUAL
function consultarSaldo() {
    console.clear();
    console.log("=== SALDO ACTUAL ===");
    console.log(`💰 Su saldo es: $${usuario.saldo.toLocaleString()}`);//imprimir saldo
    setTimeout(mostrarMenuPrincipal, 2000);
}



// RETIRAR DINERO CON VALIDACIONES
function retirarDinero() {
    console.clear();
    console.log("=== RETIRAR DINERO ===");
    console.log(`Saldo actual: $${usuario.saldo.toLocaleString()}`);
    
    // Solicitar monto a retirar    
    const monto = parseFloat(prompt("¿Cuánto desea retirar? 💸")); //ingrese información y convertir en texto
    
    
    // isNaN(monto) verifica si NO es número
    // monto <= 0 verifica si es negativo o cero
    if (isNaN(monto) || monto <= 0) {
        console.log("❌ Monto no válido. Debe ser un número positivo .");
        setTimeout(retirarDinero, 1500);
        return;
    }
    
    // Validar que haya saldo suficiente
    if (monto > usuario.saldo) {
        console.log("❌ Fondos insuficientes. No puede retirar más de su saldo actual --> ponete a camellar 🐫🧌.");
        setTimeout(mostrarMenuPrincipal, 1500);
        return;
    }
    
    // Realizar el retiro (actualizar saldo) se accede al objeto porpiedad saldo y rsta al monto
    usuario.saldo -= monto;
    
    
    // Registrar el movimiento creando el objeto y lo  guardamos en la varible
    ultimoMovimiento = {
        tipo: "Retiro",
        monto: monto,
        fecha: new Date().toLocaleString()//formatp fecha
    };
    
    console.log(`✅ Retiro exitoso: $${monto.toLocaleString()}`);
    console.log(`💰 Nuevo saldo: $${usuario.saldo.toLocaleString()}`);
    setTimeout(mostrarMenuPrincipal, 2500);
}



// CONSIGNAR DINERO CON VALIDACIONES
function consignarDinero() {
    console.clear();
    console.log("=== CONSIGNAR DINERO ===");
    console.log(`Saldo actual: $${usuario.saldo.toLocaleString()}`);
    
    // Solicitar monto a consignar
    const monto = parseFloat(prompt("¿Cuánto desea consignar?"));
    
    // isNaN(monto) verifica si NO es número, Validar que el monto sea un número positivo
    if (isNaN(monto) || monto <= 0) {
        console.log("❌ Monto no válido. Debe ser un número positivo.");
        setTimeout(consignarDinero, 1500);
        return;
    }
    
    // Realizar la consignación (actualizar saldo)
    usuario.saldo += monto;
    
    // Registrar el movimiento en el objeto
    ultimoMovimiento = {
        tipo: "Consignación",
        monto: monto,
        fecha: new Date().toLocaleString()
    };
    
    console.log(`✅ Consignación exitosa: $${monto.toLocaleString()}`);
    console.log(`💰 Nuevo saldo: $${usuario.saldo.toLocaleString()}`);
    setTimeout(mostrarMenuPrincipal, 2500);
}


// VER ÚLTIMO MOVIMIENTO REGISTRADO
function verUltimoMovimiento() {
    console.clear();
    console.log("=== ÚLTIMO MOVIMIENTO ===");
    
    if (ultimoMovimiento === null) {
        console.log("No hay movimientos registrados.");
    } else {
        // Mostrar información del último movimiento
        console.log(`Tipo: ${ultimoMovimiento.tipo}`);
        console.log(`Monto: $${ultimoMovimiento.monto.toLocaleString()}`);
        console.log(`Fecha: ${ultimoMovimiento.fecha}`);
    }
    
    setTimeout(mostrarMenuPrincipal, 2000);
}


// CAMBIAR CONTRASEÑA CON VALIDACIONES
function cambiarContrasena() {
    console.clear();
    console.log("=== CAMBIAR CONTRASEÑA ===");
    
    // Solicitar contraseña actual para validación
    const claveActual = prompt("Ingrese su contraseña actual:");
    
    // Validar contraseña actual
    if (claveActual !== usuario.clave) {
        console.log("❌ Contraseña actual incorrecta");
        setTimeout(mostrarMenuPrincipal, 1500);
        return;
    }
    
    // Solicitar nueva contraseña
    const nuevaClave = prompt("Ingrese su nueva contraseña:");
    const confirmarClave = prompt("Confirme su nueva contraseña:");
    
    // Validar que las contraseñas coincidan
    if (nuevaClave !== confirmarClave) {
        console.log("❌ Las contraseñas no coinciden");
        setTimeout(cambiarContrasena, 1500);
        return;
    }
    
    // Validar que la nueva contraseña no esté vacía
    if (!nuevaClave) {
        console.log("❌ La contraseña no puede estar vacía");
        setTimeout(cambiarContrasena, 1500);
        return;
    }
    
    // Actualizar contraseña
    usuario.clave = nuevaClave;
    console.log("✅ Contraseña cambiada exitosamente");
    setTimeout(mostrarMenuPrincipal, 1500);
}



// CERRAR SESIÓN Y VOLVER AL MENÚ PRINCIPAL

function cerrarSesion() {
    sesionActiva = false;  // Desactivar bandera de sesión
    console.log("👋 Sesión cerrada. ¡Hasta pronto picha muerta!");
    setTimeout(iniciarSistema, 1500);
}

// INICIALIZAR EL SISTEMA
// =============================================
alert("bienvenido a nuestro sistema de cajero!");
console.log("🔹 Sistema bancario inicializado");
console.log("🔹 Por favor registre una cuenta para comenzar");
//setTimeout(iniciarSistema, 1000);

iniciarSistema();