// =============================================
// CONSTANTES Y CONFIGURACIÓN
// =============================================
const MAX_INTENTOS_LOGIN = 3;
const MENSAJE_BIENVENIDA = "=== CAJERO AUTOMÁTICO DE BANCOLOMBIA ===\n-Donde se cae el sistema todos los fines de mes 👌🟢";

// =============================================
// CLASES PARA MEJORAR LA ESTRUCTURA
// =============================================
class Movimiento {
    constructor(tipo, monto) {
        this.tipo = tipo;
        this.monto = monto;
        this.fecha = new Date().toLocaleString();
    }
}

class Usuario {
    constructor(identificacion, nombreUsuario, correo, clave) {
        this.identificacion = identificacion;
        this.nombreUsuario = nombreUsuario;
        this.correo = correo;
        this.clave = clave;
        this.saldo = 0;
        this.bloqueada = false;
    }
}

// =============================================
// MÓDULO PRINCIPAL DEL SISTEMA
// =============================================
const SistemaBancario = (() => {
    // Estado del sistema
    let usuario = null;
    let intentosLogin = 0;
    let sesionActiva = false;
    let ultimoMovimiento = null;
    
    // Utilidades
    const mostrarMensajeTemporal = (mensaje, tiempo, callback) => {
        console.clear();
        console.log(mensaje);
        setTimeout(callback, tiempo);
    };
    
    const validarCamposObligatorios = (campos) => {
        return campos.every(campo => campo && campo.trim() !== '');
    };
    
    const formatearMonto = (monto) => {
        return `$${monto.toLocaleString()}`;
    };
    
    // Funciones de navegación
    const volverAlMenuPrincipal = () => {
        mostrarMenuPrincipal();
    };
    
    const volverAlInicio = () => {
        iniciarSistema();
    };
    
    // Funciones principales
    const iniciarSistema = () => {
        console.clear();
        console.log(MENSAJE_BIENVENIDA);
        console.log("1. Registrar nueva cuenta");
        console.log("2. Iniciar sesión");
        console.log("3. Salir");
        
        const opcion = prompt("Seleccione una opción (1-3): \n1. Registrar nueva cuenta \n2. Iniciar sesión \n3. Salir ");
        
        switch(opcion) {
            case "1":
                registrarUsuario();
                break;
            case "2":
                iniciarSesion();
                break;
            case "3":
                alert("¡Gracias por usar nuestro cajero!");
                break;
            default:
                mostrarMensajeTemporal("Opción no válida", 1000, iniciarSistema);
        }
    };
    
    const registrarUsuario = () => {
        console.clear();
        console.log("=== REGISTRAR NUEVA CUENTA ===");
        
        if (usuario !== null) {
            mostrarMensajeTemporal("❌ Ya existe una cuenta registrada.", 2000, iniciarSistema);
            return;
        }
        
        const identificacion = prompt("Ingrese su número de identificación:");
        const nombreUsuario = prompt("Cree un nombre de usuario:");
        const correo = prompt("Ingrese su correo electrónico:");
        const clave = prompt("Cree una contraseña:");
        const confirmarClave = prompt("Confirme su contraseña:");
        
        if (clave !== confirmarClave) {
            mostrarMensajeTemporal("❌ Las contraseñas no coinciden. Intente nuevamente.", 2000, registrarUsuario);
            return;
        }
        
        if (!validarCamposObligatorios([identificacion, nombreUsuario, correo, clave])) {
            mostrarMensajeTemporal("❌ Todos los campos son obligatorios.", 2000, registrarUsuario);
            return;
        }
        
        usuario = new Usuario(identificacion, nombreUsuario, correo, clave);
        ultimoMovimiento = new Movimiento("Apertura de cuenta", 0);
        
        console.log("✅ ¡Cuenta creada exitosamente!");
        console.log(`Bienvenido/a ${nombreUsuario}`);
        console.log("Su saldo inicial es: $0");
        
        setTimeout(iniciarSistema, 3000);
    };
    
    const iniciarSesion = () => {
        console.clear();
        console.log("=== INICIAR SESIÓN ===");
        
        if (usuario === null) {
            mostrarMensajeTemporal("❌ No hay cuentas registradas. Por favor regístrese primero.", 2000, iniciarSistema);
            return;
        }
        
        if (usuario.bloqueada) {
            mostrarMensajeTemporal("❌ Cuenta bloqueada. Contacte al banco.", 2000, iniciarSistema);
            return;
        }
        
        const inputUsuario = prompt("Ingrese su usuario:");
        const inputClave = prompt("Ingrese su contraseña:");
        
        if (inputUsuario === usuario.nombreUsuario && inputClave === usuario.clave) {
            console.log("✅ ¡Login exitoso!");
            intentosLogin = 0;
            sesionActiva = true;
            setTimeout(mostrarMenuPrincipal, 1000);
        } else {
            intentosLogin++;
            
            console.log(`❌ Credenciales incorrectas. Intento ${intentosLogin}/${MAX_INTENTOS_LOGIN}`);
            
            if (intentosLogin >= MAX_INTENTOS_LOGIN) {
                usuario.bloqueada = true;
                mostrarMensajeTemporal("🚫 Cuenta bloqueada por seguridad", 2000, iniciarSistema);
            } else {
                setTimeout(iniciarSistema, 2000);
            }
        }
    };
    
    const mostrarMenuPrincipal = () => {
        console.clear();
        console.log("=== MENÚ PRINCIPAL ===");
        console.log(`Usuario: ${usuario.nombreUsuario}`);
        console.log("1. Consultar saldo");
        console.log("2. Retirar dinero");
        console.log("3. Consignar dinero");
        console.log("4. Ver último movimiento");
        console.log("5. Cambiar contraseña");
        console.log("6. Cerrar sesión");

        const opcion = prompt("Seleccione una opción (1-6): \n1. Consultar saldo \n2. Retirar dinero \n3. Consignar dinero  \n4. Ver último movimiento \n5. Cambiar contraseña \n6. Cerrar sesión");
        
        switch(opcion) {
            case "1":
                consultarSaldo();
                break;
            case "2":
                retirarDinero();
                break;
            case "3":
                consignarDinero();
                break;
            case "4":
                verUltimoMovimiento();
                break;
            case "5":
                cambiarContrasena();
                break;
            case "6":
                cerrarSesion();
                break;
            default:
                mostrarMensajeTemporal("Opción no válida", 1000, mostrarMenuPrincipal);
        }
    };
    
    const consultarSaldo = () => {
        console.clear();
        console.log("=== SALDO ACTUAL ===");
        console.log(`💰 Su saldo es: ${formatearMonto(usuario.saldo)}`);
        setTimeout(volverAlMenuPrincipal, 2000);
    };
    
    const retirarDinero = () => {
        console.clear();
        console.log("=== RETIRAR DINERO ===");
        console.log(`Saldo actual: ${formatearMonto(usuario.saldo)}`);
        
        const monto = parseFloat(prompt("¿Cuánto desea retirar? 💸"));
        
        if (isNaN(monto) || monto <= 0) {
            mostrarMensajeTemporal("❌ Monto no válido. Debe ser un número positivo.", 1500, retirarDinero);
            return;
        }
        
        if (monto > usuario.saldo) {
            mostrarMensajeTemporal("❌ Fondos insuficientes. No puede retirar más de su saldo actual.", 1500, volverAlMenuPrincipal);
            return;
        }
        
        usuario.saldo -= monto;
        ultimoMovimiento = new Movimiento("Retiro", monto);
        
        console.log(`✅ Retiro exitoso: ${formatearMonto(monto)}`);
        console.log(`💰 Nuevo saldo: ${formatearMonto(usuario.saldo)}`);
        setTimeout(volverAlMenuPrincipal, 2500);
    };
    
    const consignarDinero = () => {
        console.clear();
        console.log("=== CONSIGNAR DINERO ===");
        console.log(`Saldo actual: ${formatearMonto(usuario.saldo)}`);
        
        const monto = parseFloat(prompt("¿Cuánto desea consignar?"));
        
        if (isNaN(monto) || monto <= 0) {
            mostrarMensajeTemporal("❌ Monto no válido. Debe ser un número positivo.", 1500, consignarDinero);
            return;
        }
        
        usuario.saldo += monto;
        ultimoMovimiento = new Movimiento("Consignación", monto);
        
        console.log(`✅ Consignación exitosa: ${formatearMonto(monto)}`);
        console.log(`💰 Nuevo saldo: ${formatearMonto(usuario.saldo)}`);
        setTimeout(volverAlMenuPrincipal, 2500);
    };
    
    const verUltimoMovimiento = () => {
        console.clear();
        console.log("=== ÚLTIMO MOVIMIENTO ===");
        
        if (ultimoMovimiento === null) {
            console.log("No hay movimientos registrados.");
        } else {
            console.log(`Tipo: ${ultimoMovimiento.tipo}`);
            console.log(`Monto: ${formatearMonto(ultimoMovimiento.monto)}`);
            console.log(`Fecha: ${ultimoMovimiento.fecha}`);
        }
        
        setTimeout(volverAlMenuPrincipal, 2000);
    };
    
    const cambiarContrasena = () => {
        console.clear();
        console.log("=== CAMBIAR CONTRASEÑA ===");
        
        const claveActual = prompt("Ingrese su contraseña actual:");
        
        if (claveActual !== usuario.clave) {
            mostrarMensajeTemporal("❌ Contraseña actual incorrecta", 1500, volverAlMenuPrincipal);
            return;
        }
        
        const nuevaClave = prompt("Ingrese su nueva contraseña:");
        const confirmarClave = prompt("Confirme su nueva contraseña:");
        
        if (nuevaClave !== confirmarClave) {
            mostrarMensajeTemporal("❌ Las contraseñas no coinciden", 1500, cambiarContrasena);
            return;
        }
        
        if (!nuevaClave) {
            mostrarMensajeTemporal("❌ La contraseña no puede estar vacía", 1500, cambiarContrasena);
            return;
        }
        
        usuario.clave = nuevaClave;
        mostrarMensajeTemporal("✅ Contraseña cambiada exitosamente", 1500, volverAlMenuPrincipal);
    };
    
    const cerrarSesion = () => {
        sesionActiva = false;
        mostrarMensajeTemporal("👋 Sesión cerrada. ¡Hasta pronto!", 1500, volverAlInicio);
    };
    
    // API pública del módulo
    return {
        iniciar: () => {
            alert("Bienvenido a nuestro sistema de cajero!");
            console.log("🔹 Sistema bancario inicializado");
            console.log("🔹 Por favor registre una cuenta para comenzar");
            iniciarSistema();
        }
    };
})();

// INICIALIZAR EL SISTEMA
SistemaBancario.iniciar();